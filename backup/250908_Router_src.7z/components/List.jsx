
function List() {
  return (
    <>
      <h2>리스트 페이지</h2>
    </>
  )
}

export default List;