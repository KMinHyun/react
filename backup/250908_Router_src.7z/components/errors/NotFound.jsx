function NotFound() {
  return (
    <>
      <h2 style={{color: 'red'}}>Not Found</h2>
    </>
  )
}

export default NotFound;